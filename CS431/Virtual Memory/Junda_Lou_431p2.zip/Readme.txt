1. Compile and run Main.java
2. It accepts 2 command line arguments (Absolute path is recommended)
   (1) args[0] = The path to the test file containing instructions
   (2) args[1] = The path to the folder containing page files
3. Output csv files will be generated in the same folder as those source code files
