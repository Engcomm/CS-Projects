No group members, just me
Junda Lou

1. Enter the quantity of the integers
2. Enter those integers 1 by 1
3. It will automatically print out the sorted integers for you
4. Enter the integer you want to search for
5. It will say "Found" if it is in the series
6. It will say "Not found" if it is not in the series
