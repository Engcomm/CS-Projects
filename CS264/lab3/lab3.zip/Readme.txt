1. Enter the quantity of the integers
2. Enter those integers 1 by 1
3. It will automatically print out the sorted integers for you
