It will ask for an input "n" first.
Enter an integer that > 0, but not too big so that a 32-bit word can hold.
Press enter, and results will show automatically.
