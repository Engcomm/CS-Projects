Compile Main.cpp with --std=c++11 and run it
