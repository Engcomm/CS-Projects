1. Compile the Main.java
2. Run it
3. If you want to see the whole process, uncomment the print statements in algorithms